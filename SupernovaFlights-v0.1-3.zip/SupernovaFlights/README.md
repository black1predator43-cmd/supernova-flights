# Supernova Flights

Первое Android-приложение Supernova Airlines.

## v0.1
- фирменное тёмное табло рейсов;
- рейсы SNN1–SNN24 из текущей маршрутной сети;
- фильтры «Сегодня / Завтра / Вся сеть»;
- вычисляемые статусы: Scheduled / Boarding / En route / Arrived;
- live progress по плановым STD/STA;
- карточка рейса с бортом, типом ВС, временем и шкалой маршрута;
- SNN23/SNN24 закреплены за TC-SNZ Sirius (A350-900).

## Сборка
Откройте корень проекта в Android Studio и выполните **Build > Build APK(s)**.

Требования проекта: JDK 17+, compileSdk 36, minSdk 26.

## Данные
В v0.1 данные хранятся локально в `FlightRepository.kt`. Это намеренно: ключ Airtable не помещается в APK. Следующая версия должна получать JSON от Supernova API, который уже общается с Airtable/Notion на серверной стороне.
