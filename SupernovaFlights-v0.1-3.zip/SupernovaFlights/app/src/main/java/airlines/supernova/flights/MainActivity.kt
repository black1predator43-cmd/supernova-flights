package airlines.supernova.flights

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Background = Color(0xFF080A0F)
private val Panel = Color(0xFF11151D)
private val PanelAlt = Color(0xFF171C26)
private val Border = Color(0xFF27303D)
private val TextPrimary = Color(0xFFF4F6FA)
private val TextSecondary = Color(0xFF98A4B5)
private val Accent = Color(0xFF8CC8FF)
private val ActiveGreen = Color(0xFF58D39B)
private val BoardingAmber = Color(0xFFFFC76B)
private val Development = Color(0xFF7E8897)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SupernovaApp() }
    }
}

private enum class BoardFilter { TODAY, TOMORROW, NETWORK }

@Composable
fun SupernovaApp() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            var selected by remember { mutableStateOf<Pair<FlightTemplate, LocalDate>?>(null) }
            if (selected == null) {
                FlightBoard(onFlightSelected = { template, date -> selected = template to date })
            } else {
                FlightDetail(
                    template = selected!!.first,
                    date = selected!!.second,
                    onBack = { selected = null },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlightBoard(onFlightSelected: (FlightTemplate, LocalDate) -> Unit) {
    val istZone = remember { ZoneId.of("Europe/Istanbul") }
    var now by remember { mutableStateOf(ZonedDateTime.now(istZone)) }
    var filter by remember { mutableStateOf(BoardFilter.TODAY) }

    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now(istZone)
            delay(15_000)
        }
    }

    val today = now.toLocalDate()
    val date = when (filter) {
        BoardFilter.TODAY -> today
        BoardFilter.TOMORROW -> today.plusDays(1)
        BoardFilter.NETWORK -> today
    }
    val rows = when (filter) {
        BoardFilter.NETWORK -> FlightRepository.flights.map { FlightRepository.occurrence(it, today) }
        else -> FlightRepository.occurrencesFor(date)
    }

    Scaffold(
        containerColor = Background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                title = {
                    Column {
                        Text("SUPERNOVA", color = TextPrimary, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("FLIGHT BOARD", color = TextSecondary, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                },
                actions = {
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 16.dp)) {
                        Text(now.format(DateTimeFormatter.ofPattern("HH:mm:ss")), color = TextPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text("IST / UTC+3", color = TextSecondary, fontSize = 10.sp)
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(
                    "Operations schedule",
                    color = TextPrimary,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Text(
                    now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)),
                    color = TextSecondary,
                    fontSize = 13.sp,
                )
                Text("Schedule times shown in Zulu (UTC)", color = TextSecondary, fontSize = 11.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip("Today", filter == BoardFilter.TODAY) { filter = BoardFilter.TODAY }
                    FilterChip("Tomorrow", filter == BoardFilter.TOMORROW) { filter = BoardFilter.TOMORROW }
                    FilterChip("Network", filter == BoardFilter.NETWORK) { filter = BoardFilter.NETWORK }
                }
                Spacer(Modifier.height(6.dp))
            }

            items(rows, key = { it.template.number }) { flight ->
                FlightRow(
                    flight = flight,
                    now = now,
                    showOperatingDay = filter == BoardFilter.NETWORK,
                    onClick = { onFlightSelected(flight.template, date) },
                )
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text(
                    "v0.1 · Local operations data · Supernova Airlines",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                )
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (selected) TextPrimary else Panel,
            labelColor = if (selected) Background else TextSecondary,
        ),
        border = AssistChipDefaults.assistChipBorder(
            enabled = true,
            borderColor = if (selected) TextPrimary else Border,
            borderWidth = 1.dp,
        ),
    )
}

@Composable
private fun FlightRow(
    flight: FlightOccurrence,
    now: ZonedDateTime,
    showOperatingDay: Boolean,
    onClick: () -> Unit,
) {
    val phase = flight.phase(now)
    val progress = if (flight.template.networkStatus == NetworkStatus.ACTIVE) flight.progress(now) else 0f
    val animatedProgress by animateFloatAsState(progress, label = "flightProgress")

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    flight.template.number,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black,
                )
                Spacer(Modifier.weight(1f))
                StatusPill(flight.template, phase)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(flight.template.origin, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                Icon(Icons.Default.Flight, contentDescription = null, tint = Accent, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(flight.template.destination, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        flight.departure.format(DateTimeFormatter.ofPattern("HH:mm'Z'")),
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                    )
                    Text("STD", color = TextSecondary, fontSize = 10.sp)
                }
            }

            AnimatedVisibility(phase == FlightPhase.EN_ROUTE && flight.template.networkStatus == NetworkStatus.ACTIVE) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier.fillMaxWidth().height(5.dp),
                        color = Accent,
                        trackColor = PanelAlt,
                    )
                    Spacer(Modifier.height(6.dp))
                    Row {
                        Text("${flight.progressPercent(now)}% flown", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${formatMinutes(flight.remainingMinutes(now))} remaining", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = Border)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AirplanemodeActive, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    buildString {
                        append(flight.template.registration ?: "Aircraft TBA")
                        flight.template.aircraftName?.let { append(" · $it") }
                    },
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.weight(1f))
                if (showOperatingDay) {
                    Text(
                        flight.template.operatingDays.joinToString(" ") { it.name.take(2) },
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                    )
                } else {
                    Text(
                        "STA ${flight.arrival.format(DateTimeFormatter.ofPattern("HH:mm'Z'"))}",
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPill(template: FlightTemplate, phase: FlightPhase) {
    val (label, color) = if (template.networkStatus == NetworkStatus.DEVELOPMENT) {
        "DEVELOPMENT" to Development
    } else {
        when (phase) {
            FlightPhase.SCHEDULED -> "SCHEDULED" to TextSecondary
            FlightPhase.BOARDING -> "BOARDING" to BoardingAmber
            FlightPhase.EN_ROUTE -> "EN ROUTE" to ActiveGreen
            FlightPhase.ARRIVED -> "ARRIVED" to ActiveGreen
        }
    }
    Box(
        modifier = Modifier.background(color.copy(alpha = 0.13f), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 5.dp),
    ) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlightDetail(template: FlightTemplate, date: LocalDate, onBack: () -> Unit) {
    val istZone = remember { ZoneId.of("Europe/Istanbul") }
    var now by remember { mutableStateOf(ZonedDateTime.now(istZone)) }
    val flight = remember(template, date) { FlightRepository.occurrence(template, date) }

    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now(istZone)
            delay(10_000)
        }
    }

    val detailTargetProgress = if (template.networkStatus == NetworkStatus.ACTIVE) flight.progress(now) else 0f
    val progress by animateFloatAsState(detailTargetProgress, label = "detailProgress")
    val phase = flight.phase(now)

    Scaffold(
        containerColor = Background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                title = { Text(template.number, color = TextPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black) },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                StatusPill(template, phase)
                Spacer(Modifier.height(14.dp))
                Text("${template.origin} → ${template.destination}", color = TextPrimary, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Text("${template.originName} to ${template.destinationName}", color = TextSecondary, fontSize = 14.sp)
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border),
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(template.origin, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.weight(1f))
                            Text("${if (template.networkStatus == NetworkStatus.ACTIVE) flight.progressPercent(now) else 0}%", color = Accent, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
                            Spacer(Modifier.weight(1f))
                            Text(template.destination, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = Accent,
                            trackColor = PanelAlt,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            when (phase) {
                                FlightPhase.EN_ROUTE -> "${formatMinutes(flight.remainingMinutes(now))} to destination"
                                FlightPhase.BOARDING -> "Departure in ${formatMinutes(flight.remainingMinutes(now))}"
                                FlightPhase.SCHEDULED -> "Scheduled operation"
                                FlightPhase.ARRIVED -> "Flight completed"
                            },
                            color = TextSecondary,
                            fontSize = 12.sp,
                        )
                    }
                }
            }

            item {
                InfoCard("Schedule") {
                    InfoLine(Icons.Default.CalendarMonth, "Date", date.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)))
                    InfoLine(Icons.Default.Schedule, "STD", flight.departure.format(DateTimeFormatter.ofPattern("HH:mm'Z'")))
                    InfoLine(Icons.Default.AccessTime, "STA", flight.arrival.format(DateTimeFormatter.ofPattern("HH:mm'Z'")))
                    InfoLine(Icons.Default.AccessTime, "Block", formatMinutes(template.blockMinutes.toLong()))
                }
            }

            item {
                InfoCard("Aircraft") {
                    InfoLine(Icons.Default.AirplanemodeActive, "Registration", template.registration ?: "TBA")
                    InfoLine(Icons.Default.Flight, "Aircraft", template.aircraftType ?: "TBA")
                    InfoLine(Icons.Default.AirplanemodeActive, "Name", template.aircraftName ?: "—")
                }
            }

            item {
                Text(
                    if (template.networkStatus == NetworkStatus.ACTIVE)
                        "Operational route · Supernova Airlines"
                    else
                        "Route is present in the network but remains in development until aircraft assignment/activation.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                )
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title.uppercase(), color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(9.dp))
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text(value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}

private fun formatMinutes(minutes: Long): String {
    val safe = minutes.coerceAtLeast(0)
    val hours = safe / 60
    val mins = safe % 60
    return if (hours > 0) "%dh %02dm".format(hours, mins) else "%dm".format(mins)
}
