package airlines.supernova.flights

import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.roundToInt

enum class NetworkStatus { ACTIVE, DEVELOPMENT }
enum class FlightPhase { SCHEDULED, BOARDING, EN_ROUTE, ARRIVED }

data class FlightTemplate(
    val number: String,
    val origin: String,
    val destination: String,
    val originName: String,
    val destinationName: String,
    val departureZulu: LocalTime,
    val blockMinutes: Int,
    val operatingDays: Set<DayOfWeek>,
    val aircraftType: String? = null,
    val registration: String? = null,
    val aircraftName: String? = null,
    val networkStatus: NetworkStatus = NetworkStatus.DEVELOPMENT,
)

data class FlightOccurrence(
    val template: FlightTemplate,
    val departure: ZonedDateTime,
    val arrival: ZonedDateTime,
) {
    fun phase(now: ZonedDateTime): FlightPhase {
        val utcNow = now.withZoneSameInstant(ZoneId.of("UTC"))
        val boardingStart = departure.minusMinutes(45)
        return when {
            utcNow.isBefore(boardingStart) -> FlightPhase.SCHEDULED
            utcNow.isBefore(departure) -> FlightPhase.BOARDING
            utcNow.isBefore(arrival) -> FlightPhase.EN_ROUTE
            else -> FlightPhase.ARRIVED
        }
    }

    fun progress(now: ZonedDateTime): Float {
        val utcNow = now.withZoneSameInstant(ZoneId.of("UTC"))
        if (utcNow.isBefore(departure)) return 0f
        if (!utcNow.isBefore(arrival)) return 1f
        val total = Duration.between(departure, arrival).seconds.toDouble()
        val elapsed = Duration.between(departure, utcNow).seconds.toDouble()
        return (elapsed / total).coerceIn(0.0, 1.0).toFloat()
    }

    fun progressPercent(now: ZonedDateTime): Int = (progress(now) * 100f).roundToInt()

    fun remainingMinutes(now: ZonedDateTime): Long {
        val utcNow = now.withZoneSameInstant(ZoneId.of("UTC"))
        return when {
            utcNow.isBefore(departure) -> Duration.between(utcNow, departure).toMinutes()
            utcNow.isBefore(arrival) -> Duration.between(utcNow, arrival).toMinutes()
            else -> 0L
        }
    }
}

object FlightRepository {
    private val daily = DayOfWeek.values().toSet()
    private val weekdays = setOf(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY,
    )

    val flights: List<FlightTemplate> = listOf(
        FlightTemplate("SNN1", "IST", "AKL", "Istanbul", "Auckland", LocalTime.of(20, 0), 1200,
            setOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY),
            "Airbus A350-1000ULR", "TC-SNV", "Antares", NetworkStatus.ACTIVE),
        FlightTemplate("SNN2", "AKL", "IST", "Auckland", "Istanbul", LocalTime.of(15, 0), 1200,
            setOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY),
            "Airbus A350-1000ULR", "TC-SNV", "Antares", NetworkStatus.ACTIVE),
        FlightTemplate("SNN3", "IST", "SYD", "Istanbul", "Sydney", LocalTime.of(5, 0), 1080, daily),
        FlightTemplate("SNN4", "SYD", "IST", "Sydney", "Istanbul", LocalTime.of(0, 30), 1140, daily),
        FlightTemplate("SNN5", "IST", "MEL", "Istanbul", "Melbourne", LocalTime.of(15, 0), 1080,
            setOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY)),
        FlightTemplate("SNN6", "MEL", "IST", "Melbourne", "Istanbul", LocalTime.of(10, 30), 1140,
            setOf(DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SUNDAY)),
        FlightTemplate("SNN7", "IST", "SIN", "Istanbul", "Singapore", LocalTime.of(12, 30), 630, weekdays),
        FlightTemplate("SNN8", "SIN", "IST", "Singapore", "Istanbul", LocalTime.of(0, 30), 690,
            setOf(DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY)),
        FlightTemplate("SNN9", "IST", "HKG", "Istanbul", "Hong Kong", LocalTime.of(19, 0), 600, daily),
        FlightTemplate("SNN10", "HKG", "IST", "Hong Kong", "Istanbul", LocalTime.of(6, 30), 660, daily),
        FlightTemplate("SNN11", "IST", "LAX", "Istanbul", "Los Angeles", LocalTime.of(12, 0), 840,
            setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY)),
        FlightTemplate("SNN12", "LAX", "IST", "Los Angeles", "Istanbul", LocalTime.of(3, 30), 780,
            setOf(DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)),
        FlightTemplate("SNN13", "IST", "SFO", "Istanbul", "San Francisco", LocalTime.of(2, 0), 840,
            setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY)),
        FlightTemplate("SNN14", "SFO", "IST", "San Francisco", "Istanbul", LocalTime.of(17, 30), 780,
            setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY)),
        FlightTemplate("SNN15", "IST", "PKX", "Istanbul", "Beijing Daxing", LocalTime.of(8, 30), 570, daily),
        FlightTemplate("SNN16", "PKX", "IST", "Beijing Daxing", "Istanbul", LocalTime.of(19, 30), 630, daily),
        FlightTemplate("SNN17", "IST", "PER", "Istanbul", "Perth", LocalTime.of(0, 30), 870,
            setOf(DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)),
        FlightTemplate("SNN18", "PER", "IST", "Perth", "Istanbul", LocalTime.of(16, 30), 930,
            setOf(DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)),
        FlightTemplate("SNN19", "IST", "ADL", "Istanbul", "Adelaide", LocalTime.of(14, 30), 1020,
            setOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY)),
        FlightTemplate("SNN20", "ADL", "IST", "Adelaide", "Istanbul", LocalTime.of(9, 0), 1080,
            setOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)),
        FlightTemplate("SNN21", "IST", "HND", "Istanbul", "Tokyo Haneda", LocalTime.of(22, 30), 690, daily),
        FlightTemplate("SNN22", "HND", "IST", "Tokyo Haneda", "Istanbul", LocalTime.of(11, 30), 750, daily),
        FlightTemplate("SNN23", "IST", "SVO", "Istanbul", "Moscow Sheremetyevo", LocalTime.of(8, 0), 190, daily,
            "Airbus A350-900", "TC-SNZ", "Sirius", NetworkStatus.ACTIVE),
        FlightTemplate("SNN24", "SVO", "IST", "Moscow Sheremetyevo", "Istanbul", LocalTime.of(13, 10), 195, daily,
            "Airbus A350-900", "TC-SNZ", "Sirius", NetworkStatus.ACTIVE),
    )

    fun occurrencesFor(date: LocalDate): List<FlightOccurrence> = flights
        .filter { date.dayOfWeek in it.operatingDays }
        .map { template ->
            val departure = ZonedDateTime.of(date, template.departureZulu, ZoneId.of("UTC"))
            FlightOccurrence(template, departure, departure.plusMinutes(template.blockMinutes.toLong()))
        }
        .sortedBy { it.departure }

    fun occurrence(template: FlightTemplate, date: LocalDate): FlightOccurrence {
        val departure = ZonedDateTime.of(date, template.departureZulu, ZoneId.of("UTC"))
        return FlightOccurrence(template, departure, departure.plusMinutes(template.blockMinutes.toLong()))
    }
}
