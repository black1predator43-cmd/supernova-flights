# Android Studio setup

1. Install a current stable Android Studio.
2. Open the folder `SupernovaFlights` as a project.
3. Let Android Studio install/sync Android SDK 36 and Gradle dependencies.
4. Run on a device/emulator with Android 8.0 (API 26) or newer.
5. To create an APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

The app intentionally contains no Airtable token or Notion credentials.

## Next data-integration step
Replace `FlightRepository` with an HTTP repository calling a small Supernova backend. The backend should hold the Airtable personal access token and return only the fields needed by the mobile app.
